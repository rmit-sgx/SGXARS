<?php
    session_start();
    if(!isset($_SESSION['username'])){
        header("Location: login.html");
    }

    $updated_content_for_users_txt="";
    foreach(file('enclave/users.txt') as $line) {
        if(strlen($line)>3 && $line!="\n"){
            $line=rtrim($line);
            list($username,$password,$score) = explode(",",$line);
            //echo $line."++++++++++++++++\n";
            $new_score = 0;
            $updated_content_for_users_txt .= $username.",".$password.",";
            // update all users' reputation scores
            foreach(file('enclave/messages.txt') as $line2) {
                if(strlen($line2)>3){
                    //echo $line2;
                    list($username2,$pid,$message,$likes,$dislikes) = explode(",",$line2);
                    //echo $likes."=";
                    if($username==$username2){
                        //echo "yes";
                        //echo "new_score = ".intval($new_score);
                        //echo "likes = ".intval($likes);
                        //echo "dislikes = ".intval($dislikes);
                        $new_score = intval($new_score) + intval($likes);
                        $new_score = intval($new_score) - intval($dislikes);
                        //echo intval($new_score);
                    }
                }
            }
            $updated_content_for_users_txt .= $new_score."\n";
            if($username==$_SESSION['username']){
                $self_score = $new_score;
            }
        }
    }
    file_put_contents('enclave/users.txt', $updated_content_for_users_txt);


    function encrypt($plaintext, $password) {
        $method = "AES-256-CBC";
        $key = hash('sha256', $password, true);
        $iv = openssl_random_pseudo_bytes(16);

        $ciphertext = openssl_encrypt($plaintext, $method, $key, OPENSSL_RAW_DATA, $iv);
        $hash = hash_hmac('sha256', $ciphertext.$iv, $key, true);

        //return $iv.$hash.$ciphertext;
        return $ciphertext;
    }

    function decrypt($ivHashCiphertext, $password) {
        $method = "AES-256-CBC";
        $iv = substr($ivHashCiphertext, 0, 16);
        $hash = substr($ivHashCiphertext, 16, 32);
        $ciphertext = substr($ivHashCiphertext, 48);
        $key = hash('sha256', $password, true);

        //if (!hash_equals(hash_hmac('sha256', $ciphertext.$iv, $key, true), $hash)) return null;

        return openssl_decrypt($ciphertext, $method, $key, OPENSSL_RAW_DATA, $iv);
    }

    function reputation_score_level($name){
        $reputation_score=0;
        $score_level = "Low";

        foreach(file('enclave/users.txt') as $line) {
            if(strlen($line)>3 && $line!="\n"){
                $line=rtrim($line);
                list($username,$password,$score) = explode(",",$line);
                if($username==$name){
                    $reputation_score=$score;
                    break;
                }
            }
        }

        if(intval($reputation_score)<=5){
            $score_level = "Low";
        }
        if(intval($reputation_score)>5&&intval($reputation_score)<=10){
            $score_level = "Medium";
        }
        if(intval($reputation_score)>10){
            $score_level = "High";
        }

        return $score_level;
    }

    //echo encrypt('Plaintext string.', 'password');

    //echo "<br/>".decrypt(encrypt('Plaintext string.', 'password'),'password');

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>SGX - message board</title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Stylesheet -->
    <link href="style.css" rel="stylesheet">

    <!-- Responsive CSS -->
    <link href="css/responsive/responsive.css" rel="stylesheet">

</head>

<body>
    
   
    <!-- ****** Top Header Area Start ****** -->
    <div class="top_header_area">
        <div class="container">
            <div class="row">
                    <div class="signup-search-area d-flex align-items-center justify-content-end" style="position: absolute;left: 50px">
                        <div class="login_register_area d-flex">
                            <!-- <div class="login">
                                <a href="login.html">Sign in</a>
                            </div> -->
                            <div class="register">
                                <a href="#">Practical SGX-based Anonymous Reputation System</a>
                            </div>
                        </div>
                       
                    </div>
                    <div class="signup-search-area d-flex align-items-center justify-content-end" style="position: absolute;right: 50px">
                        <div class="login_register_area d-flex">
                            <div class="login">
                                <a href="message_board.php">Message board</a>
                            </div>
                            <div class="register">
                                <a href="php/signout.php">Sign out</a>
                            </div>
                        </div>
                       
                    </div>
            </div>
        </div>
    </div>
    <!-- ****** Top Header Area End ****** -->

    <!-- ****** Header Area Start ****** -->
    <header class="header_area" id="header_title">
        <div class="container">
            <div class="row">
                <!-- Logo Area Start -->
                <div class="col-12">
                    <div class="logo_area text-center">
                        <a href="index.html" class="yummy-logo">Reputation board</a>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- ****** Header Area End ****** -->

    <input type="hidden" id="fake_names" name="fake_names" value="<?php echo $fake_names;?>"/>

    <!-- ****** Single Blog Area Start ****** -->
    <section class="single_blog_area section_padding_80" id="message_board">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-10">
                    <div class="row no-gutters">
                        <!-- Single Post -->
                        <div class="col-10 col-sm-11">
                            <!-- Comment Area Start -->
                            <div class="comment_area section_padding_50 clearfix" id="all_comments">

                                        <li class="single_comment_area">
                                            <div class="comment-wrapper d-flex">
                                                <!-- Comment Meta -->
                                                <div class="comment-author">
                                                    <img src="<?php echo 'img/blog-img/'.rand(17,19).'.jpg';?>" alt="">
                                                </div>
                                                <!-- Comment Content -->
                                                <div class="comment-content">
                                                    <h5>
                                                        <?php 
                                                            echo "My ID: ".$_SESSION['username']." (".reputation_score_level($_SESSION['username']).")";
                                                        ?>
                                                    </h5>
                                                    <p>
                                                        <?php 
                                                            echo "Reputation score: ".$self_score;
                                                        ?>
                                                    </p>
                                                </div>
                                            </div>
                                        </li>
                                        <hr>
                                        <br/>

                                    <?php
                                        //read users.txt line by line
                                        foreach(file('enclave/users.txt') as $line) {

                                            if(strlen($line)>3){
                                                list($username,$password,$score) = explode(",",$line);
                                                if($_SESSION['username']!=$username){
                                    ?>
                                        <!-- Single Comment Area -->
                                        <li class="single_comment_area">
                                            <div class="comment-wrapper d-flex">
                                                <!-- Comment Meta -->
                                                <div class="comment-author">
                                                    <img src="<?php echo 'img/blog-img/'.rand(17,19).'.jpg';?>" alt="">
                                                </div>
                                                <!-- Comment Content -->
                                                <div class="comment-content">
                                                    <!-- <span class="comment-date text-muted">27 Aug 2018</span> -->
                                                    <h5>
                                                        <?php 
                                                            echo "Pseudo ID: ".hash('sha256', $username.$password);
                                                        ?>
                                                    </h5>
                                                    <p>
                                                        <?php 
                                                                echo "Reputation score: ".encrypt($score, $password);
                                                        ?>
                                                    </p>
                                                   
                                                </div>
                                            </div>
                                        </li>
                                    <?php
                                                }
                                            }
                                        }
                                    ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <br/><br/><br/>
    <!-- ****** Single Blog Area End ****** -->

    

    <!-- Jquery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap-4 js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins JS -->
    <script src="js/others/plugins.js"></script>
    <!-- Active JS -->
    <script src="js/active.js"></script>

    
</body>
