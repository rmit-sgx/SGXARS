<?php
    session_start();
    if(!isset($_SESSION['username'])){
        header("Location: login.html");
    }

    //get all fake names
    $fake_names = "";
    foreach(file('enclave/messages.txt') as $line) {
        if(strlen($line)>3){
           list($username,$pid,$message,$likes,$dislikes) = explode(",",$line);
           $fake_names = $fake_names.",".$pid;
        }
    }

    $error = "";
    if(isset($_GET['error'])){
        $error = $_GET['error'];
    }


    function reputation_score_level($name){
    	$reputation_score=0;
    	$score_level = "Low";

    	foreach(file('enclave/users.txt') as $line) {
	        if(strlen($line)>3 && $line!="\n"){
	            $line=rtrim($line);
	            list($username,$password,$score) = explode(",",$line);
	            if($username==$name){
	            	$reputation_score=$score;
	            	break;
	            }
	        }
	    }

	    if(intval($reputation_score)<=5){
            $score_level = "Low";
	    }
	    if(intval($reputation_score)>5&&intval($reputation_score)<=10){
            $score_level = "Medium";
	    }
	    if(intval($reputation_score)>10){
            $score_level = "High";
	    }

	    return $score_level;
    }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>SGX - Message Board</title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Stylesheet -->
    <link href="style.css" rel="stylesheet">

    <!-- Responsive CSS -->
    <link href="css/responsive/responsive.css" rel="stylesheet">

</head>

<body>
    
   
    <!-- ****** Top Header Area Start ****** -->
    <div class="top_header_area">
        <div class="container">
            <div class="row">
                    <div class="signup-search-area d-flex align-items-center justify-content-end" style="position: absolute;left: 50px">
                        <div class="login_register_area d-flex">
                            <!-- <div class="login">
                                <a href="login.html">Sign in</a>
                            </div> -->
                            <div class="register">
                                <a href="#">Practical SGX-based Anonymous Reputation System</a>
                            </div>
                        </div>
                       
                    </div>
                    <div class="signup-search-area d-flex align-items-center justify-content-end" style="position: absolute;right: 50px">
                        <div class="login_register_area d-flex">
                            <div class="login">
                                <a href="reputation_board.php">Reputation board</a>
                            </div>
                            <div class="register">
                                <a href="php/signout.php">Sign out</a>
                            </div>
                        </div>
                       
                    </div>
            </div>
        </div>
    </div>
    <!-- ****** Top Header Area End ****** -->

    <!-- ****** Header Area Start ****** -->
    <header class="header_area" id="header_title">
        <div class="container">
            <div class="row">
                <!-- Logo Area Start -->
                <div class="col-12">
                    <div class="logo_area text-center">
                        <a href="index.html" class="yummy-logo">Message Board</a>
                        <br/>
                        <div style="color:red;font-size: 22px"><?php echo $error;?></div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- ****** Header Area End ****** -->

    <input type="hidden" id="fake_names" name="fake_names" value="<?php echo $fake_names;?>"/>

    <form action="php/feedback.php" method="post" id="feedback_comment_form">
        <input type="hidden" id="target_fake_name" name="target_fake_name" value=""/>
        <input type="hidden" id="feedback_result" name="feedback_result" value=""/>
    </form>

    <!-- ****** Single Blog Area Start ****** -->
    <section class="single_blog_area section_padding_80" id="message_board">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-10">
                    <div class="row no-gutters">
                        <!-- Single Post -->
                        <div class="col-10 col-sm-11">
                            <!-- Comment Area Start -->
                            <div class="comment_area section_padding_50 clearfix" id="all_comments">

                                    <?php
                                        //read users.txt line by line
                                        foreach(file('enclave/messages.txt') as $line) {

                                            if(strlen($line)>3){
                                                list($username,$pid,$message,$likes,$dislikes) = explode(",",$line);
                                            
                                    ?>
                                        <!-- Single Comment Area -->
                                        <li class="single_comment_area">
                                            <div class="comment-wrapper d-flex">
                                                <!-- Comment Meta -->
                                                <div class="comment-author">
                                                    <img src="<?php echo 'img/blog-img/'.rand(17,19).'.jpg';?>" alt="">
                                                </div>
                                                <!-- Comment Content -->
                                                <div class="comment-content">
                                                    <!-- <span class="comment-date text-muted">27 Aug 2018</span> -->

                                                    <h5>
                                                        <?php echo $pid." (".reputation_score_level($username).")";?>
                                                        <?php
                                                            if($_SESSION['username']==$username){
                                                                echo " <- my post";
                                                            }
                                                        ?>
                                                    </h5>
                                                    <p><?php echo $message;?></p>
                                                    <a class="active" onclick="like('<?php echo $pid;?>')"><i class="fa fa-thumbs-up" aria-hidden="true"></i> <?php echo $likes;?></a>
                                                    <a onclick="dislike('<?php echo $pid;?>')"><i class="fa fa-thumbs-down" aria-hidden="true"></i> <?php echo $dislikes;?></a>

                                                   
                                                </div>
                                            </div>
                                        </li>
                                    <?php
                                            }
                                        }
                                    ?>
                            </div>



                            <!-- Leave A Comment -->
                            <div class="leave-comment-area section_padding_50 clearfix">
                                <div class="comment-form">
                                    <h4 class="mb-30">Leave A Comment</h4>
                                    <!-- Comment Form -->
                                    <form action="php/new_comment.php" id="post_comment_form" method="post" onkeyup="keyPress()">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="fake_name" name="fake_name" placeholder="Please non-used fake name">
                                        </div>
                                        <div id="fake_name_error" style="display: none; color:red;"></div>
                                       <!--  <div class="form-group">
                                            <input type="email" class="form-control" id="contact-email" placeholder="Email">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="contact-website" placeholder="Website">
                                        </div> -->
                                        <div class="form-group">
                                            <textarea class="form-control" name="message" id="message" cols="30" rows="10" placeholder="Enter your comment"></textarea>
                                            <div id="comment_error" style="display: none; color:red;"></div>
                                        </div>
                                        <button type="button" id="post_comment_button" class="btn contact-btn" onclick="sendMessage()" disabled>Post Comment</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ****** Single Blog Area End ****** -->

    

    <!-- Jquery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap-4 js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins JS -->
    <script src="js/others/plugins.js"></script>
    <!-- Active JS -->
    <script src="js/active.js"></script>

    <script type="text/javascript">

        function keyPress(){
            var fake_names = document.getElementById("fake_names").value.split(",");
            var new_fake_name = document.getElementById("fake_name").value;
            var comment = document.getElementById("message").value;
            comment = comment.replace(/,/g,"");
            comment = comment.replace(/\n/g,"");
            document.getElementById("message").value = comment;


            //console.log(fake_names);
            //console.log(new_fake_name);
            if(new_fake_name!=""){
                if(fake_names.includes(new_fake_name)==true){
                    
                    document.getElementById("fake_name_error").style.display = "block";
                    document.getElementById("fake_name_error").innerHTML = "The fake name has been used!";
                }else{
                    document.getElementById("post_comment_button").disabled = false;
                    document.getElementById("fake_name_error").style.display = "none";
                }
            }else{
                document.getElementById("fake_name_error").innerHTML = "The fake name cannot be empty!";
            }

            if(comment==""){
                    document.getElementById("comment_error").style.display = "block";
                    document.getElementById("comment_error").innerHTML = "The comment cannot be empty!";
            }else{
                    document.getElementById("comment_error").style.display = "none";
            }

            if(document.getElementById("fake_name_error").style.display=="none"&&document.getElementById("comment_error").style.display=="none"){
                document.getElementById("post_comment_button").disabled = false;
            }else{
                document.getElementById("post_comment_button").disabled = true;
            }
        }


       
        function sendMessage(){
            var name = document.getElementById("fake_name").value;
            var message = document.getElementById("message").value;

            //console.log(name+":"+message);
            // var userLogo = Math.floor(Math.random() * 3) + 17;

            // var div = document.getElementById('all_comments');

            // div.innerHTML += "<li class=\"single_comment_area\"><div class=\"comment-wrapper d-flex\"><div class=\"comment-author\"><img src=\"img/blog-img/"+userLogo+".jpg\"></div><div class=\"comment-content\"><h5>"+name+"</h5><p>"+message+"</p><a class=\"active\" id=\""+name+"likes\" onclick=\"like('"+name+"likes')\"><i class=\"fa fa fa-thumbs-up\" aria-hidden=\"true\"></i> 0</a><a id=\""+name+"dislikes\" onclick=\"like('"+name+"dislikes')\"><i class=\"fa fa-thumbs-down\" aria-hidden=\"true\"></i> 0</a></div></div></li>";

            //document.getElementById("fake_name").value = "";
            //document.getElementById("message").value = "";

            document.getElementById("post_comment_form").submit();

        }

        function like(fake_name){
            document.getElementById("target_fake_name").value = fake_name;
            document.getElementById("feedback_result").value = "like";
            document.getElementById("feedback_comment_form").submit();
        }
        function dislike(fake_name){
            document.getElementById("target_fake_name").value = fake_name;
            document.getElementById("feedback_result").value = "dislike";
            document.getElementById("feedback_comment_form").submit();
        }

        // function like(user){
        //     var likes = document.getElementById(user).innerHTML;
        //     var icon_likes = likes.split('</i> ');
        //     document.getElementById(user).innerHTML = icon_likes[0] +"</i> "+(parseInt(icon_likes[1])+1);
        // }


        // function dislike(user){
        //     var dislikes = document.getElementById(user).innerHTML;
        //     var icon_dislikes = dislikes.split('</i> ');
        //     document.getElementById(user).innerHTML = icon_dislikes[0] +"</i> "+(parseInt(icon_dislikes[1])+1);
        // }
    </script>
</body>
