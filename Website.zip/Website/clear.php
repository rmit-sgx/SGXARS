
<?php
    //file_put_contents('enclave/users.txt', "");
    file_put_contents('enclave/messages.txt', "");
    file_put_contents('enclave/likes.txt', "");
    file_put_contents('enclave/dislikes.txt', "");

    header('Location: index.html');
?>


